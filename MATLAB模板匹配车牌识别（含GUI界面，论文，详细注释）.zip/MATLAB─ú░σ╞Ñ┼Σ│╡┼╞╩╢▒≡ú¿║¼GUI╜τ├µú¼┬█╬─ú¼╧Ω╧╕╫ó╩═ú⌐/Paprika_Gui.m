function varargout = Paprika_Gui(varargin)
% PAPRIKA_GUI MATLAB code for Paprika_Gui.fig
%      PAPRIKA_GUI, by itself, creates a new PAPRIKA_GUI or raises the existing
%      singleton*.
%
%      H = PAPRIKA_GUI returns the handle to a new PAPRIKA_GUI or the handle to
%      the existing singleton*.
%
%      PAPRIKA_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PAPRIKA_GUI.M with the given input arguments.
%
%      PAPRIKA_GUI('Property','Value',...) creates a new PAPRIKA_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Paprika_Gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Paprika_Gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Paprika_Gui

% Last Modified by GUIDE v2.5 28-Aug-2021 21:28:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @Paprika_Gui_OpeningFcn, ...
    'gui_OutputFcn',  @Paprika_Gui_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Paprika_Gui is made visible.
function Paprika_Gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Paprika_Gui (see VARARGIN)

% Choose default command line output for Paprika_Gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Paprika_Gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Paprika_Gui_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname]=uigetfile('Originalpicture\*.jpg', 'File Selector');
I=imread([pathname '\' filename]);%�������������ǰ��������һ��·��
handles.I=I;
guidata(hObject, handles);%%�����Լ��ı���
axes(handles.axes1);
imshow(I);title('ԭͼ');

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

msgbox('����������ϵ����ʦq115195686')













% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(gcf);


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
YuanShi=handles.I;
YuanShiHuiDu=rgb2gray(YuanShi);%ת��Ϊ�Ҷ�ͼ��
BianYuan=edge(YuanShiHuiDu,'canny',0.2);%Canny���ӱ�Ե���
%BianYuan=edge(YuanShiHuiDu,'roberts',0.2,'both');
axes(handles.axes2);
imshow(BianYuan);
save BianYuan
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
load BianYuan
se1=[1;1;1]; %���ͽṹԪ��
FuShi=imerode(BianYuan,se1);    %��ʴͼ��
axes(handles.axes3);
imshow(FuShi);
save FuShi
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
load FuShi
se2=strel('rectangle',[25,25]); %���νṹԪ��
TianChong=imclose(FuShi,se2);%ͼ����ࡢ���ͼ��
YuanShiLvBo=bwareaopen(TianChong,2000);%�Ӷ������Ƴ����С��2000��С����
axes(handles.axes4);
imshow(YuanShiLvBo);
save YuanShiLvBo
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
load YuanShiLvBo
[y,x]=size(YuanShiLvBo);%size������������������ص���һ�������������������������ص��ڶ����������
YuCuDingWei=double(YuanShiLvBo);
%%%%%%%%%2.ȷ���е���ʼλ�ú���ֹλ��%%%%%%%%%%%
Y1=zeros(y,1);%����y��1��ȫ������
for i=1:y
    for j=1:x
        if(YuCuDingWei(i,j)==1)
            Y1(i,1)= Y1(i,1)+1;%��ɫ���ص�ͳ��
        end
    end
end
[temp,MaxY]=max(Y1);%Y����������ȷ��������������temp��MaxY��temp������¼Y1��ÿ�е����ֵ��MaxY������¼Y1ÿ�����ֵ���к�

PY1=MaxY;
while ((Y1(PY1,1)>=50)&&(PY1>1))%����ߵ㿪ʼ�������ұ߽�
    PY1=PY1-1;
end
PY2=MaxY;
while ((Y1(PY2,1)>=50)&&(PY2<y))
    PY2=PY2+1;
end
IY=YuanShi(PY1:PY2,:,:);
%%%%%%%%%%���ƴֶ�λ֮��ȷ���е���ʼλ�ú���ֹλ��%%%%%%%%%%%
%%%%%%%%%%���зָͬ����Ǵ��������м���%%%%%%%%%%%%%%
X1=zeros(1,x);%����1��x��ȫ������
for j=1:x
    for i=PY1:PY2
        if(YuCuDingWei(i,j,1)==1)
            X1(1,j)= X1(1,j)+1;
        end
    end
end

PX1=1;
while ((X1(1,PX1)<3)&&(PX1<x))
    PX1=PX1+1;
end
PX3=x;
while ((X1(1,PX3)<3)&&(PX3>PX1))
    PX3=PX3-1;
end
CuDingWei=YuanShi(PY1:PY2,PX1+10:PX3-10,:);%����
axes(handles.axes5);
imshow(CuDingWei);
%%%%%%%%%%2.3�����ƾ���λ֮һԤ����%%%%%%%%%%%
CuDingWeiHuiDu=rgb2gray(CuDingWei); %��RGBͼ��ת��Ϊ�Ҷ�ͼ��
%axes(handles.axes6);
%imshow(CuDingWeiHuiDu);
c_max=double(max(max(CuDingWeiHuiDu)));
c_min=double(min(min(CuDingWeiHuiDu)));
T=round(c_max-(c_max-c_min)/3); %TΪ��ֵ������ֵ
CuDingWeiErZhi=im2bw(CuDingWeiHuiDu,T/256);
CuDingWeiErZhi=bwareaopen(CuDingWeiErZhi,20);
CuDingWeiErZhi(: ,PX3-4)=0;
CuDingWeiErZhi=bwareaopen(CuDingWeiErZhi,100);

CuDingWeiErZhi=lvbo(CuDingWeiErZhi);
save CuDingWeiErZhi

%axes(handles.axes7);
%imshow(CuDingWeiErZhi);

% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
msgbox('������������ϵ����ʦQ115195686')
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
